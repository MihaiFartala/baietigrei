# Maze-solver-AI
Python AI maze solver

Video to operate - https://www.youtube.com/watch?v=rBSqUfZFjA0

Make Sure download full folder

StackFrontier = Depth for Search

QueuFrontier = Breadth for Search

Depth for Search goes in depth and find wether point to reach is there or not.

Breadth for Search goes in all directions at once, one by one to find target.


to change in Depth for Search and Breadth for Search, change frontier in line 127 in Maze.py file.

How to run = Open your Terminal Window and and type - " python maze.py (Puzzle you want to Solve) "
example - "python maze.py maze2.txt"

Output of solving would be saved in same folder in image form, and you can make your custom puzzles make sure make .txt file you can see example in maze1.txt,maze2.txt or maze3.txt file


A is starting point in puzzle and B is target to reach.

Use Online IDE.

preffered Online IDE = https://ide.cs50.io
